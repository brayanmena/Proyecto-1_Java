package com.parameta.springbookRegistro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbookRegistroApplicationTests {

	@Test
	void contextLoads() {
	}

}
