package com.parameta.springbookRegistro.dao;

import com.parameta.springbookRegistro.models.Empleado;

public interface EmpleadoDao {
    Empleado registrar(Empleado empleado);
}
