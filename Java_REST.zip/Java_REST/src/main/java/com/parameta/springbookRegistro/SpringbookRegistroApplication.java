package com.parameta.springbookRegistro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbookRegistroApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbookRegistroApplication.class, args);
	}

}
